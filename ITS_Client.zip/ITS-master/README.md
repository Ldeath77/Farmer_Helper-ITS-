------------------------GROUP-14-----------------------
ITS folder represents the code for our client side.
ITS_server tar file contains code for server side.
The code should be run on iiits server.
